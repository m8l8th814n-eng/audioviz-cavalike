# braille-viz

Terminal audio spectrum visualizer rendered with Unicode braille characters.
Captures system audio output via PulseAudio/PipeWire and draws a real-time FFT
spectrum at 2× horizontal resolution per terminal cell.

## Requirements

- Rust (edition 2021, tested on 1.95)
- `parec` and `pactl` (`pulseaudio-utils`, or PipeWire's pulse compatibility layer)
- A running PulseAudio or PipeWire server

## Build

```sh
cargo build --release
```

The binary lands at `target/release/braille-viz`.

## Run

```sh
./target/release/braille-viz
```

Captures the monitor source of the default sink (auto-detected via
`pactl get-default-sink`). Without audio playing the screen will be blank.

Quit with `q`, `Esc`, or `Ctrl+C`.

## Tuning

Constants at the top of `src/main.rs`:

| Constant         | Default | Effect                                                    |
|------------------|---------|-----------------------------------------------------------|
| `SAMPLE_RATE`    | 44100   | parec capture rate                                        |
| `FFT_SIZE`       | 2048    | FFT window size (frequency resolution = rate / size)      |
| `HOP`            | 512     | Samples per render frame (~12 ms at 44.1 kHz)             |
| `MIN_FREQ`       | 40      | Lowest displayed frequency (Hz)                           |
| `MAX_FREQ`       | 4000    | Highest displayed frequency (Hz)                          |
| `NOISE_FLOOR_DB` | -65     | Magnitude floor (silence)                                 |
| `CEILING_DB`     | -10     | Magnitude ceiling (full bar)                              |
| `ATTACK`         | 0.55    | Smoothing coefficient when value rises                    |
| `RELEASE`        | 0.12    | Smoothing coefficient when value falls                    |

Frequency mapping is linear — every bar covers the same Hz range.

## How it works

1. Spawns `parec` reading mono `s16le` from `<default-sink>.monitor`.
2. Buffers samples, applies a Hann window, runs an `FFT_SIZE`-point real FFT.
3. Computes per-bin magnitudes, partitions them into linearly spaced buckets,
   one per visual bar (2 bars per terminal column).
4. Maps magnitudes to dB and normalizes against the configured floor/ceiling.
5. Smooths each bar with asymmetric attack/release coefficients.
6. Renders bars as braille glyphs (8 dots per cell — 2 dot columns × 4 dot
   rows), coloured along a dark-blue → cyan ramp by bar height.
