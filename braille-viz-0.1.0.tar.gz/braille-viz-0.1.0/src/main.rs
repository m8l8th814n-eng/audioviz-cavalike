use std::io::{Read, Write};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;

use anyhow::{anyhow, Context, Result};
use crossterm::{
    cursor, event,
    event::{Event, KeyCode, KeyEventKind},
    execute, queue,
    style::{Color, Print, ResetColor, SetForegroundColor},
    terminal::{self, ClearType, EnterAlternateScreen, LeaveAlternateScreen},
};
use rustfft::{num_complex::Complex32, FftPlanner};

const SAMPLE_RATE: u32 = 44_100;
const FFT_SIZE: usize = 2048;
const HOP: usize = 512;
const MIN_FREQ: f32 = 40.0;
const MAX_FREQ: f32 = 4_000.0;
const NOISE_FLOOR_DB: f32 = -65.0;
const CEILING_DB: f32 = -10.0;
const ATTACK: f32 = 0.55;
const RELEASE: f32 = 0.12;

fn default_monitor() -> Result<String> {
    let out = Command::new("pactl")
        .arg("get-default-sink")
        .output()
        .context("running pactl")?;
    if !out.status.success() {
        return Err(anyhow!("pactl get-default-sink failed"));
    }
    let sink = String::from_utf8(out.stdout)?.trim().to_string();
    if sink.is_empty() {
        return Err(anyhow!("no default sink"));
    }
    Ok(format!("{}.monitor", sink))
}

fn dot_bit(dx: usize, dy: usize) -> u8 {
    match (dx, dy) {
        (0, 0) => 0x01,
        (0, 1) => 0x02,
        (0, 2) => 0x04,
        (0, 3) => 0x40,
        (1, 0) => 0x08,
        (1, 1) => 0x10,
        (1, 2) => 0x20,
        (1, 3) => 0x80,
        _ => 0,
    }
}

fn braille(bits: u8) -> char {
    char::from_u32(0x2800 + bits as u32).unwrap_or(' ')
}

fn hann(n: usize) -> Vec<f32> {
    (0..n)
        .map(|i| {
            let x = (i as f32) / ((n - 1) as f32);
            0.5 - 0.5 * (2.0 * std::f32::consts::PI * x).cos()
        })
        .collect()
}

fn bar_value(mags: &[f32], bar: usize, n_bars: usize, hz_per_bin: f32) -> f32 {
    let t_lo = bar as f32 / n_bars as f32;
    let t_hi = (bar + 1) as f32 / n_bars as f32;
    let f_lo = MIN_FREQ + (MAX_FREQ - MIN_FREQ) * t_lo;
    let f_hi = MIN_FREQ + (MAX_FREQ - MIN_FREQ) * t_hi;
    let lo = (f_lo / hz_per_bin).floor() as usize;
    let hi = ((f_hi / hz_per_bin).ceil() as usize).max(lo + 1).min(mags.len());
    let mut peak = 0.0f32;
    for &m in &mags[lo..hi] {
        if m > peak {
            peak = m;
        }
    }
    peak
}

fn db_norm(linear: f32) -> f32 {
    if linear <= 0.0 {
        return 0.0;
    }
    let db = 20.0 * linear.log10();
    ((db - NOISE_FLOOR_DB) / (CEILING_DB - NOISE_FLOOR_DB)).clamp(0.0, 1.0)
}

fn color_for(t: f32) -> Color {
    // dark blue -> light blue -> cyan
    let t = t.clamp(0.0, 1.0);
    let r = (40.0 + (180.0 - 40.0) * t).clamp(0.0, 255.0) as u8;
    let g = (80.0 + (240.0 - 80.0) * t).clamp(0.0, 255.0) as u8;
    let b = (160.0 + (255.0 - 160.0) * t).clamp(0.0, 255.0) as u8;
    Color::Rgb { r, g, b }
}

struct TermGuard;
impl TermGuard {
    fn enter() -> Result<Self> {
        terminal::enable_raw_mode()?;
        execute!(std::io::stdout(), EnterAlternateScreen, cursor::Hide)?;
        Ok(Self)
    }
}
impl Drop for TermGuard {
    fn drop(&mut self) {
        let _ = execute!(std::io::stdout(), ResetColor, cursor::Show, LeaveAlternateScreen);
        let _ = terminal::disable_raw_mode();
    }
}

fn main() -> Result<()> {
    let monitor = default_monitor()?;

    let running = Arc::new(AtomicBool::new(true));
    {
        let r = running.clone();
        ctrlc::set_handler(move || r.store(false, Ordering::SeqCst))?;
    }

    let mut child = Command::new("parec")
        .args([
            "--format=s16le",
            &format!("--rate={SAMPLE_RATE}"),
            "--channels=1",
            &format!("--device={monitor}"),
            "--latency-msec=20",
        ])
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .context("spawning parec")?;
    let mut stdout = child.stdout.take().ok_or_else(|| anyhow!("no parec stdout"))?;

    let _guard = TermGuard::enter()?;

    let mut planner = FftPlanner::<f32>::new();
    let fft = planner.plan_fft_forward(FFT_SIZE);
    let window = hann(FFT_SIZE);
    let hz_per_bin = SAMPLE_RATE as f32 / FFT_SIZE as f32;

    let mut sample_buf: Vec<f32> = Vec::with_capacity(FFT_SIZE * 2);
    let mut byte_buf = [0u8; HOP * 2];
    let mut fft_buf: Vec<Complex32> = vec![Complex32::new(0.0, 0.0); FFT_SIZE];
    let mut mags: Vec<f32> = vec![0.0; FFT_SIZE / 2];
    let mut smoothed: Vec<f32> = Vec::new();
    let mut last_size = (0u16, 0u16);
    let mut out = std::io::stdout();

    while running.load(Ordering::SeqCst) {
        if event::poll(Duration::from_millis(0))? {
            if let Event::Key(k) = event::read()? {
                if k.kind == KeyEventKind::Press
                    && matches!(k.code, KeyCode::Char('q') | KeyCode::Esc)
                {
                    break;
                }
            }
        }

        let n = match stdout.read(&mut byte_buf) {
            Ok(0) => break,
            Ok(n) => n,
            Err(_) => break,
        };
        let pairs = n / 2;
        for i in 0..pairs {
            let lo = byte_buf[i * 2] as i16;
            let hi = byte_buf[i * 2 + 1] as i16;
            let s = ((hi << 8) | (lo & 0xff)) as f32 / 32768.0;
            sample_buf.push(s);
        }

        if sample_buf.len() < FFT_SIZE {
            continue;
        }

        let start = sample_buf.len() - FFT_SIZE;
        for i in 0..FFT_SIZE {
            fft_buf[i] = Complex32::new(sample_buf[start + i] * window[i], 0.0);
        }
        if sample_buf.len() > FFT_SIZE * 2 {
            let drop = sample_buf.len() - FFT_SIZE;
            sample_buf.drain(..drop);
        }

        fft.process(&mut fft_buf);
        let norm = 2.0 / FFT_SIZE as f32;
        for i in 0..mags.len() {
            mags[i] = fft_buf[i].norm() * norm;
        }

        let (cols, rows) = terminal::size()?;
        if (cols, rows) != last_size {
            queue!(out, terminal::Clear(ClearType::All))?;
            last_size = (cols, rows);
            smoothed.clear();
        }
        if cols < 4 || rows < 2 {
            continue;
        }
        let n_bars = (cols as usize) * 2;
        let dot_rows = (rows as usize) * 4;
        if smoothed.len() != n_bars {
            smoothed = vec![0.0; n_bars];
        }

        for b in 0..n_bars {
            let v = db_norm(bar_value(&mags, b, n_bars, hz_per_bin));
            let prev = smoothed[b];
            let coef = if v > prev { ATTACK } else { RELEASE };
            smoothed[b] = prev + (v - prev) * coef;
        }

        for cell_row in 0..rows as usize {
            queue!(out, cursor::MoveTo(0, cell_row as u16))?;
            for cell_col in 0..cols as usize {
                let left = smoothed[cell_col * 2];
                let right = smoothed[cell_col * 2 + 1];
                let lh = (left * dot_rows as f32).round() as usize;
                let rh = (right * dot_rows as f32).round() as usize;
                let mut bits = 0u8;
                let mut max_t = 0.0f32;
                for dy in 0..4 {
                    let row_from_top = cell_row * 4 + dy;
                    let from_bot = dot_rows.saturating_sub(1).saturating_sub(row_from_top);
                    if from_bot < lh {
                        bits |= dot_bit(0, dy);
                        let t = from_bot as f32 / dot_rows as f32;
                        if t > max_t {
                            max_t = t;
                        }
                    }
                    if from_bot < rh {
                        bits |= dot_bit(1, dy);
                        let t = from_bot as f32 / dot_rows as f32;
                        if t > max_t {
                            max_t = t;
                        }
                    }
                }
                if bits == 0 {
                    queue!(out, Print(' '))?;
                } else {
                    queue!(out, SetForegroundColor(color_for(max_t)), Print(braille(bits)))?;
                }
            }
        }
        queue!(out, ResetColor)?;
        out.flush()?;
    }

    let _ = child.kill();
    let _ = child.wait();
    Ok(())
}
